//CSCI1300 Fall 2020
//Author: Eric Heising
//Recitation: 507-Chakraborty
//Homework 2 - Problem 2
#include <iostream>
#include <string>
using namespace std;
string userName;

int main(){
    cout <<"Enter your name:"<< endl;
    cin >> userName;
    cout << "Hello, " << userName << "!" << endl;
    return 0;
}
