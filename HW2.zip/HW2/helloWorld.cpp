//CSCI1300 Fall 2020
//Author: Eric Heising
//Recitation: 507-Chakraborty
//Homework 2 - Problem 1
#include <iostream>

using namespace std;

int main(){
    cout << "Hello, World!" << endl;
    return 0;
}